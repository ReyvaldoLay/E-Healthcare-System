package com.example.ses;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ses.record.Doctor;
import com.example.ses.record.Patient;
import com.example.ses.ui.Doctor_Profile;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    private Doctor doctor;
    private Patient patient;
    private TextView navHeaderEmail, navHeaderName;
    private AppBarConfiguration mAppBarConfiguration;
    private DatabaseReference database;
    private FirebaseUser mCurrentUser;
    private String current_uid;
    private ProgressDialog mSetupProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NavigationView ngv = findViewById(R.id.nav_view);
        View view = ngv.getHeaderView(0);
        navHeaderEmail= view.findViewById(R.id.navHeaderMail);
        navHeaderName = view.findViewById(R.id.navHeaderName);
        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        current_uid = mCurrentUser.getUid();
        database = FirebaseDatabase.getInstance().getReference();
        mSetupProgress = new ProgressDialog(this);
        mSetupProgress.setTitle("Setting up");
        mSetupProgress.setMessage("Please wait while we get your data.");
        mSetupProgress.setCanceledOnTouchOutside(false);
        mSetupProgress.show();


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        final NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_request_appointment,R.id.nav_doctor_request,R.id.nav_doctor_busy,R.id.nav_doctor_profile,R.id.nav_patient_profile,R.id.nav_send_email,R.id.nav_patient_Request)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        database.child("User").child("Doctor").child(current_uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                doctor= dataSnapshot.getValue(Doctor.class);
                if(doctor != null){
                    navHeaderName.setText(doctor.getName());
                    navHeaderEmail.setText(doctor.geteMail());
                    navigationView.getMenu().findItem(R.id.nav_request_appointment).setVisible(false);
                    navigationView.getMenu().findItem(R.id.nav_patient_profile).setVisible(false);
                    navigationView.getMenu().findItem(R.id.nav_patient_Request).setVisible(false);
                    mSetupProgress.dismiss();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        database.child("User").child("Patient").child(current_uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                patient= dataSnapshot.getValue(Patient.class);
                if(patient !=null){
                    navHeaderName.setText(patient.getName());
                    navHeaderEmail.setText(patient.getEmail());
                    navigationView.getMenu().findItem(R.id.nav_doctor_busy).setVisible(false);
                    navigationView.getMenu().findItem(R.id.nav_doctor_profile).setVisible(false);
                    navigationView.getMenu().findItem(R.id.nav_doctor_request).setVisible(false);
                    navigationView.getMenu().findItem(R.id.nav_send_email).setVisible(false);
                    mSetupProgress.dismiss();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
