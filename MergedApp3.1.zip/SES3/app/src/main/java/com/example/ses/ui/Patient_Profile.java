package com.example.ses.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.ses.R;
import com.example.ses.record.Doctor;
import com.example.ses.record.Patient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Patient_Profile extends Fragment implements View.OnClickListener {
    private TextView Name, Email, Gender;
    private EditText Location, Phone;
    private Button update;
    private Patient patient;
    private DatabaseReference database;
    private FirebaseUser mCurrentUser;
    private String current_uid;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.patient_profile, container, false);
        return root;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        current_uid = mCurrentUser.getUid();
        Name = view.findViewById(R.id.PPName);
        Email = view.findViewById(R.id.PPEmail);
        Gender = view.findViewById(R.id.PPGender);
        Location = view.findViewById(R.id.PPLocation);
        Phone = view.findViewById(R.id.PPPhone);
        update = view.findViewById(R.id.PPUpdate);
        update.setOnClickListener(this);


        database = FirebaseDatabase.getInstance().getReference();
        database.child("User").child("Patient").child(current_uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                patient= dataSnapshot.getValue(Patient.class);
                getPatientDetails(patient);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getPatientDetails(Patient p){
        Name.setText(p.getName());
        Email.setText(p.getEmail());
        Gender.setText(p.getGender());
        Location.setText(p.getAddress());
        Phone.setText(p.getPhone());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case(R.id.PPUpdate):
                if(Name.getText().toString().isEmpty()){
                    Toast.makeText(getActivity(),"please fill in name",Toast.LENGTH_SHORT).show();
                    break;
                }
                if(Location.getText().toString().isEmpty()){
                    Toast.makeText(getActivity(),"please fill in address",Toast.LENGTH_SHORT).show();
                    break;
                }
                if(Phone.getText().toString().isEmpty()){
                    Toast.makeText(getActivity(),"please fill in phone number",Toast.LENGTH_SHORT).show();
                    break;
                }
                patient.setName(Name.getText().toString());
                patient.setAddress(Location.getText().toString());
                patient.setPhone(Phone.getText().toString());
                database.child("User").child("Patient").child(current_uid).setValue(patient);
                Toast.makeText(getActivity(),"Details updated",Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
