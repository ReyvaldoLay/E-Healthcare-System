package com.example.e_healthcarelogin.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.example.e_healthcarelogin.R;

public class RegisterActivity extends AppCompatActivity {

    final EditText username = findViewById(R.id.username);
    final EditText password1 = findViewById(R.id.password1);
    final EditText Password2 = findViewById(R.id.password2);
    final Button registerDetails = findViewById(R.id.registerDetails);
    final Button logIn = findViewById(R.id.login2);

    logIn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view){
            Intent loginIntent = new Intent(RegisterActivity.this,LoginActivity.class);
            startActivity(loginIntent);
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}
