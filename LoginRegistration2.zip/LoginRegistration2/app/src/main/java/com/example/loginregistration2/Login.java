package com.example.loginregistration2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Login extends AppCompatActivity {

    Database db;
    private EditText mTextEmail;
    private EditText mTextPassword;
    private Button mBtnLogin;
    private Button mBtnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new Database(this);
        mTextEmail = (EditText) findViewById(R.id.inputEmail);
        mTextPassword = (EditText) findViewById(R.id.inputPassword);
        mBtnLogin = (Button) findViewById(R.id.loginBtn);
        mBtnRegister = (Button) findViewById(R.id.registerBtn);

        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mTextEmail.getText().toString().trim();
                String password = mTextPassword.getText().toString().trim();
                Boolean res = db.checkUser(email, password);

                if(res == true) {
                    Toast.makeText(Login.this,"Successfully logged in",Toast.LENGTH_SHORT).show();
                    Intent registrationPage = new Intent(Login.this,Register.class);
                    startActivity(registrationPage);
                } else {
                    Toast.makeText(Login.this,"Login failed",Toast.LENGTH_SHORT).show();
                }
            }
        });

        mBtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registrationPage = new Intent(Login.this, Register.class);
                startActivity(registrationPage);
            }
        });
    }
}
