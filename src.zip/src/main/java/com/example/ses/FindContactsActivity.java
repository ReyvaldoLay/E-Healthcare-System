package com.example.ses;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ses.record.Doctor;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FindContactsActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private RecyclerView FindContactsRecyclerList;
    private DatabaseReference UsersRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_contacts);

        UsersRef = FirebaseDatabase.getInstance().getReference().child("User").child("Doctor");


        FindContactsRecyclerList = (RecyclerView) findViewById(R.id.find_contacts_recycler_list);
        FindContactsRecyclerList.setLayoutManager(new LinearLayoutManager(this));

        mToolbar = (Toolbar) findViewById(R.id. find_contacts_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Find Contacts");
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerOptions<Contacts> options =
                new FirebaseRecyclerOptions.Builder<Contacts>()
                .setQuery(UsersRef,Contacts.class)
                .build();

        FirebaseRecyclerAdapter<Contacts,FindContactsViewHolder> adapter =
            new FirebaseRecyclerAdapter<Contacts, FindContactsViewHolder>(options) {
                @Override
                protected void onBindViewHolder(@NonNull FindContactsViewHolder holder, final int position, @NonNull Contacts model) {

                    holder.name.setText(model.getName());
                    holder.eMail.setText(model.geteMail());

                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            String visit_user_id = getRef(position).getKey();

                            Intent profileIntent = new Intent(FindContactsActivity.this, ProfileActivity.class);
                            profileIntent.putExtra("visit_user_id", visit_user_id);
                            startActivity(profileIntent);
                        }
                    });
                }


                @NonNull
                @Override
                public FindContactsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
                    View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.users_display_layout,viewGroup, false);
                    FindContactsViewHolder viewHolder = new FindContactsViewHolder(view);
                    return viewHolder;
                }
            };

        FindContactsRecyclerList.setAdapter(adapter);
        adapter.startListening();
}



    public static class FindContactsViewHolder extends RecyclerView.ViewHolder{
        TextView name, eMail;


        public FindContactsViewHolder(@NonNull View itemView)
        {
            super(itemView);

            name = itemView.findViewById(R.id.user_profile_name);
            eMail = itemView.findViewById(R.id.user_email);
        }
    }
}
