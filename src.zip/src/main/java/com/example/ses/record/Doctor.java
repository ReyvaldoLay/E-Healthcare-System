package com.example.ses.record;



public class Doctor{

    private String name, eMail, gender, location, speciality, credentials, phone, password;
    private int id;

    public Doctor(){}

    public Doctor(String name, String eMail, String gender, int id, String location, String speciality, String credentials, String phone, String password) {
        this.name = name;
        this.eMail = eMail;
        this.gender = gender;
        this.location = location;
        this.speciality = speciality;
        this.id = id;
        this.credentials = credentials;
        this.phone = phone;
        this.password = password;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getCredentials() {
        return credentials;
    }

    public void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String toString() {
        return name;
    }
}
