package com.example.ses;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.ses.record.Patient;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Pattern;

public class Register extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +        //any letter
                    //"(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +             //no white spaces
                    ".{6,}" +                 //at least 4 characters
                    "$");

    private EditText mTextEmail;
    private EditText mTextPassword;
    private EditText mTextPhone;
    private EditText mTextAddress;
    private Button registerBtn;
    private Button loginBtn;
    private DatabaseReference database;
    private RadioGroup userRadioGroup;
    private RadioButton userRadioBtn;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mTextEmail = (EditText) findViewById(R.id.inputNewEmail);
        mTextPassword = (EditText) findViewById(R.id.inputCfnPW);
        mTextPhone = (EditText) findViewById(R.id.inputPhone);
        mTextAddress = (EditText) findViewById(R.id.inputAddress);
        registerBtn = (Button) findViewById(R.id.registerBtn);
        loginBtn = (Button) findViewById(R.id.loginBtn2);

        database = FirebaseDatabase.getInstance().getReference();

        userRadioGroup = findViewById(R.id.radioGroup);

       registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mTextEmail.getText().toString().trim();
                String password = mTextPassword.getText().toString().trim();
                String phone = mTextPhone.getText().toString().trim();
                String address = mTextAddress.getText().toString().trim();

                int radioId = userRadioGroup.getCheckedRadioButtonId();
                userRadioBtn = findViewById(radioId);
                String userType = userRadioBtn.getText().toString().trim();

                Patient patient = new Patient(email, password, phone, address, userType);

                if(validateEmail() == true && validatePassword() == true && validatePhone() == true && validateAddress() == true) {
                    database.child("Patient").child(id+1+"").setValue(patient);
                    Toast.makeText(Register.this,"Successfully registered",Toast.LENGTH_SHORT).show();
                    Intent goLoginPage = new Intent(Register.this, Login.class);
                    startActivity(goLoginPage);
                }
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginPage = new Intent(Register.this, Login.class);
                startActivity(loginPage);
            }
        });
    }

    private void checkButton(View v) {
        int radioId = userRadioGroup.getCheckedRadioButtonId();
        userRadioBtn = findViewById(radioId);
        //Toast.makeText(this, "Seclected user type: " + userRadioBtn.getText(), Toast.LENGTH_SHORT).show();
    }

    private boolean validateEmail() {
        String emailInput = mTextEmail.getText().toString().trim();

        if (emailInput.isEmpty()) {
            mTextEmail.setError("Email can't be empty");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            mTextEmail.setError("Please enter a valid email address");
            return false;
        } else {
            mTextEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = mTextPassword.getText().toString().trim();

        if (passwordInput.isEmpty()) {
            mTextPassword.setError("Password can't be empty");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            mTextPassword.setError("Password too weak");
            return false;
        } else {
            mTextPassword.setError(null);
            return true;
        }
    }

    private boolean validatePhone() {
        String phoneInput = mTextPhone.getText().toString().trim();

        if (phoneInput.isEmpty()) {
            mTextPhone.setError("No phone number entered");
            return false;
        } else {
            mTextPhone.setError(null);
            return true;
        }
    }

    private boolean validateAddress() {
        String addressInput = mTextAddress.getText().toString().trim();

        if (addressInput.isEmpty()) {
            mTextPhone.setError("No residential address entered");
            return false;
        } else {
            mTextPhone.setError(null);
            return true;
        }
    }
}
