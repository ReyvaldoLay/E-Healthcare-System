package com.example.ses.record;



public class Doctor{

    private String firstName, middleName, lastName, eMail, gender, location, speciality, credentials, fullName;
    private int id;

    public Doctor(){}

    public Doctor(String firstName, String middleName, String lastName, String eMail, String gender, int id, String location, String speciality, String credentials) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.eMail = eMail;
        this.gender = gender;
        this.location = location;
        this.speciality = speciality;
        this.id = id;
        this.credentials = credentials;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getFullName() {
        return firstName + " " + middleName + " " + lastName;
    }

    public void SetFullName(String f, String m, String l) {
        this.fullName = f +" "+ m +" "+ l;
    }

    public String getCredentials() {
        return credentials;
    }

    public void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    public String toString() {
        return getFullName();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
