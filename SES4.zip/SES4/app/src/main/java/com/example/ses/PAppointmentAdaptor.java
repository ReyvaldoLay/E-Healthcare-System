package com.example.ses;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ses.record.Appointment;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class PAppointmentAdaptor extends RecyclerView.Adapter<AppointmentAdaptor.AppointmentViewHolder>{
    private ArrayList<Appointment> mAppointmentList;

    public static class AppointmentViewHolder extends RecyclerView.ViewHolder {
        public TextView DoctorName, PatientName, DateTime, Details;

        public AppointmentViewHolder(@NonNull View v) {
            super(v);
            DoctorName = v.findViewById(R.id.DoctorName);
            PatientName = v.findViewById(R.id.PatientName);
            DateTime = v.findViewById(R.id.DateTime);
            Details = v.findViewById(R.id.Details);
        }
    }
    public PAppointmentAdaptor(ArrayList<Appointment> appointmentList) {
        mAppointmentList = appointmentList;
    }

    @NonNull
    @Override
    public AppointmentAdaptor.AppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.patient_request_item, parent, false);
        AppointmentAdaptor.AppointmentViewHolder avh = new AppointmentAdaptor.AppointmentViewHolder(v);
        return avh;
    }

    @Override
    public void onBindViewHolder(@NonNull AppointmentAdaptor.AppointmentViewHolder holder, final int position) {
        final Appointment currentItem = mAppointmentList.get(position);
        holder.DoctorName.setText(currentItem.getDoctor().getName());
        holder.PatientName.setText(currentItem.getPatient().getName());
        holder.DateTime.setText(currentItem.getDate() + " " + currentItem.getTime());
        holder.Details.setText(currentItem.getDescription());
    }

    @Override
    public int getItemCount() {
        return mAppointmentList.size();
    }
}
