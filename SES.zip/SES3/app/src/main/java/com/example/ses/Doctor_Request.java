package com.example.ses;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ses.record.Appointment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Doctor_Request extends Fragment implements View.OnClickListener{
    private EditText editText;
    private Button button;
    private FirebaseDatabase database;
    private DatabaseReference myRef;
    private ArrayList<Appointment> appointments = new ArrayList<Appointment>();
    private ArrayList<Appointment> doctorAppointments = new ArrayList<Appointment>();
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private RadioGroup statusRadio;
    private RadioButton radioButton;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.doctor_request, container, false);
        return root;
    }
    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        editText = view.findViewById(R.id.editText);
        button = view.findViewById(R.id.button);
        button.setOnClickListener(this);
        statusRadio = view.findViewById(R.id.RadioGroupStatus);
        mRecyclerView = view.findViewById(R.id.RecyclerView);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mAdapter = new AppointmentAdaptor(doctorAppointments);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Appointment");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                appointments.clear();
                for(DataSnapshot child : dataSnapshot.getChildren()){
                    Appointment appointment  = child.getValue(Appointment.class);
                    appointments.add(appointment);
                }
                view.findViewById(R.id.loadingPanel).setVisibility(View.GONE);
                setActiveRecycler();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        statusRadio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                setActiveRecycler();
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                setActiveRecycler();
                Toast.makeText(getActivity(),"loaded " + doctorAppointments.size() +" appointments",Toast.LENGTH_SHORT).show();
                break;
        }
    }
    public void setActiveRecycler(){
        doctorAppointments.clear();
        int selectedId = statusRadio.getCheckedRadioButtonId();
        radioButton = getView().findViewById(selectedId);
        String selected = radioButton.getText().toString();

        int id;
        String doctorId = editText.getText().toString();
        if(doctorId.equals("")){
            Toast.makeText(getActivity(),"please enter your doctor id",Toast.LENGTH_SHORT).show();
            id = 0;
        }
        else
            id = Integer.parseInt(doctorId);

        for(Appointment app: appointments) {
            if (app.getDoctor().getId() == id && app.getStatus().equals(selected)) {
                doctorAppointments.add(app);
            }
        }
        mAdapter.notifyDataSetChanged();
    }
}
