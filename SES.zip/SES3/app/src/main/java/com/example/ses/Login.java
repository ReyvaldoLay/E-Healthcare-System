package com.example.ses;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ses.record.Appointment;
import com.example.ses.record.Doctor;
import com.example.ses.record.Patient;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Login extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    //"(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{6,}" +               //at least 4 characters
                    "$");

    private EditText mTextEmail;
    private EditText mTextPassword;
    private Button mBtnLogin;
    private Button mBtnRegister;
    private DatabaseReference database;
    private ArrayList<Patient> patients = new ArrayList<Patient>();
    private ArrayList<Doctor> doctors = new ArrayList<Doctor>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mTextEmail = (EditText) findViewById(R.id.inputEmail);
        mTextPassword = (EditText) findViewById(R.id.inputPassword);
        mBtnLogin = (Button) findViewById(R.id.loginBtn);
        mBtnRegister = (Button) findViewById(R.id.registerBtn);
        database = FirebaseDatabase.getInstance().getReference();

        database.child("User").child("Patient").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                patients.clear();
                for(DataSnapshot child : dataSnapshot.getChildren()){
                    Patient i  = child.getValue(Patient.class);
                    patients.add(i);
                }
                Toast.makeText(Login.this,"users are loaded",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        database.child("User").child("Doctor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                patients.clear();
                for(DataSnapshot child : dataSnapshot.getChildren()){
                    Doctor i  = child.getValue(Doctor.class);
                    doctors.add(i);
                }
                Toast.makeText(Login.this,"users are loaded",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mTextEmail.getText().toString().trim();
                String password = mTextPassword.getText().toString().trim();
                int counter =0;
                for(Patient p : patients) {
                    if (p.getEmail().equals(email) && p.getPassword().equals(password)) {
                        Toast.makeText(Login.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
                        Intent registrationPage = new Intent(Login.this, MainActivity.class);
                        startActivity(registrationPage);
                        counter++;
                        break;
                    }
                }
                for(Doctor p : doctors) {
                    if (p.geteMail().equals(email) && p.getPassword().equals(password)) {
                        Toast.makeText(Login.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
                        Intent registrationPage = new Intent(Login.this, MainActivity.class);
                        startActivity(registrationPage);
                        counter++;
                        break;
                    }
                }
                if(counter ==0) {
                    validateEmail();
                    validatePassword();
                    Toast.makeText(Login.this, "Login failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mBtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registrationPage = new Intent(Login.this, Register.class);
                startActivity(registrationPage);
            }
        });

    }

    private boolean validateEmail() {
        String emailInput = mTextEmail.getText().toString().trim();

        if (emailInput.isEmpty()) {
            mTextEmail.setError("Email can't be empty");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            mTextEmail.setError("Please enter a valid email address");
            return false;
        } else {
            mTextEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = mTextPassword.getText().toString().trim();

        if (passwordInput.isEmpty()) {
            mTextPassword.setError("Password can't be empty");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            mTextPassword.setError("Password too weak");
            return false;
        } else {
            mTextPassword.setError(null);
            return true;
        }
    }
}
