package com.example.ses.record;

import com.example.ses.record.Doctor;
import com.example.ses.record.Patient;

public class Appointment{

    Doctor doctor;
    Patient patient;
    String description, date, time, status;
    int id;

    public Appointment(){
    }
    public Appointment(Doctor doctor, Patient patient, String date, String time, String description,int id, String status){
        this.doctor = doctor;
        this.patient = patient;
        this.date = date;
        this.time = time;
        this.description = description;
        this.id = id;
        this.status = status;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
