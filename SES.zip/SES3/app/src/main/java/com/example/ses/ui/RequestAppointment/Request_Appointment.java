package com.example.ses.ui.RequestAppointment;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.ses.R;
import com.example.ses.record.Appointment;
import com.example.ses.record.Doctor;
import com.example.ses.record.Patient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Request_Appointment extends Fragment implements View.OnClickListener{
    private TextView mDisplayDate, gender, location, credential;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Button button1, button2;
    private Spinner TypeSpinner, DoctorSpinner, TimeSpinner;
    private RadioGroup genderRadio;
    private RadioButton radioButton;
    private EditText editText2;
    private Doctor doctor;
    private Patient patient;
    private DatabaseReference database;
    private int id = 0;
    private List<Doctor> FullDoctorList;
    private FirebaseUser mCurrentUser;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.request_appointment, container, false);
        return root;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        String current_uid = mCurrentUser.getUid();
        final List<Doctor> DoctorList = new ArrayList<>();
        final List<String> TypeList = new ArrayList<>();
        FullDoctorList = new ArrayList<>();
        final List<String> BusyList = new ArrayList<>();
        final List<Appointment> ListAppointment = new ArrayList<>();
        final List<String> TimeList = new ArrayList<>();
        mDisplayDate = view.findViewById(R.id.dateText);
        gender = view.findViewById(R.id.textView3);
        location = view.findViewById(R.id.textView5);
        credential = view.findViewById(R.id.textView6);
        editText2 = view.findViewById(R.id.editText2);
        genderRadio = view.findViewById(R.id.RadioGroupGender);
        button1 = view.findViewById(R.id.button1);
        button2 = view.findViewById(R.id.button2);
        DoctorSpinner = view.findViewById(R.id.DoctorSpinner);
        TypeSpinner = view.findViewById(R.id.TypeSpinner);
        TimeSpinner = view.findViewById(R.id.TimeSpinner);
        button2.setOnClickListener(this);
        button1.setOnClickListener(this);
        addTypes(TypeList);
        database = FirebaseDatabase.getInstance().getReference();

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                String date = day + "-" + month + "-" + year;
                mDisplayDate.setText(date);
                setTimeSpinner(ListAppointment,TimeList,BusyList);
            }
        };
        TypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id)
            {
                setDoctorSpinner(FullDoctorList, DoctorList);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        DoctorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                doctor = (Doctor)parent.getSelectedItem();
                setGLC(doctor);
                setTimeSpinner(ListAppointment,TimeList,BusyList);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        genderRadio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                setDoctorSpinner(FullDoctorList, DoctorList);
            }
        });
        database.child("Appointment").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ListAppointment.clear();
                for(DataSnapshot child : dataSnapshot.getChildren()){
                    Appointment appointment  = child.getValue(Appointment.class);
                    if(appointment.getId()>id){id = appointment.getId();}
                    ListAppointment.add(appointment);
                }
                }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        database.child("Busy_Times").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                BusyList.clear();
                for(DataSnapshot child : dataSnapshot.getChildren()){
                    String docId  = child.getKey();
                    child.getChildren();
                    for(DataSnapshot child2 : child.getChildren()){
                        String i = child2.getKey();
                        BusyList.add(docId +" "+ i);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        database.child("User").child("Doctor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                FullDoctorList.clear();
                for(DataSnapshot child : dataSnapshot.getChildren()){
                    Doctor doc  = child.getValue(Doctor.class);
                    FullDoctorList.add(doc);
                }
                addTypes(TypeList);
                view.findViewById(R.id.loadingPanel).setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        database.child("User").child("Patient").child(current_uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                patient= dataSnapshot.getValue(Patient.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button2:
                Calendar calDate = Calendar.getInstance();
                int year = calDate.get(Calendar.YEAR);
                int month = calDate.get(Calendar.MONTH);
                int day = calDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialogDate = new DatePickerDialog(
                        getContext(),
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialogDate.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialogDate.show();
                break;

            case R.id.button1:
                if(!mDisplayDate.equals("Date") || !editText2.equals("")) {
                    Appointment appointment = new Appointment(doctor, patient, mDisplayDate.getText().toString(), TimeSpinner.getSelectedItem().toString(), editText2.getText().toString(), id + 1, "Pending");

                    database.child("Appointment").child(id + 1 + "").setValue(appointment);
                    Toast.makeText(getActivity(),"Appointment requested",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getActivity(),"please choose a time and fill in appointment details",Toast.LENGTH_SHORT).show();
                }
                        break;
        }
    }

    private void addTypes(List TypeList) {
        TypeList.clear();
        for(Doctor d : FullDoctorList){
            TypeList.add(d.getSpeciality());
        }
        List<String> noDupes = new ArrayList<>(new HashSet<String>(TypeList));
        noDupes.remove("");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, noDupes);
        TypeSpinner.setAdapter(arrayAdapter);
    }

    public void setTimeSpinner(List<Appointment> AppointmentList, List TimeList, List<String> BusyList){
        TimeList.clear();
        TimeList.add("9:00");
        TimeList.add("9:30");
        TimeList.add("10:00");
        TimeList.add("10:30");
        TimeList.add("11:00");
        TimeList.add("11:30");
        TimeList.add("12:00");
        TimeList.add("12:30");
        TimeList.add("13:00");
        TimeList.add("13:30");
        TimeList.add("14:00");
        TimeList.add("14:30");
        TimeList.add("15:00");
        TimeList.add("15:30");
        TimeList.add("16:00");
        TimeList.add("16:30");
        Doctor localDoctor = (Doctor) DoctorSpinner.getSelectedItem();
        for(Appointment appointment: AppointmentList)
        {
            if(mDisplayDate.getText().equals(appointment.getDate()) && appointment.getDoctor().getId() == localDoctor.getId()) {
                TimeList.remove(appointment.getTime());
            }
        }
        for(String busy: BusyList)
        {
            String [] split = busy.split(" ");
            if(split[0].equals(Integer.toString(localDoctor.getId())) && split[1].equals(mDisplayDate.getText().toString())){
                TimeList.remove(split[2]);
            }
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, TimeList);
        TimeSpinner.setAdapter(arrayAdapter);
    }

    private void setDoctorSpinner(List<Doctor> FullDoctorList, List<Doctor> DoctorList) {
        int selectedId = genderRadio.getCheckedRadioButtonId();
        radioButton = getView().findViewById(selectedId);
        String type = TypeSpinner.getSelectedItem().toString();
        DoctorList.clear();
        switch (radioButton.getText().toString()) {
            case "Both":
                for (Doctor doctor : FullDoctorList) {
                    if (doctor.getSpeciality().equals(type))
                        DoctorList.add(doctor);
                }
                break;
            case "Male":
                for (Doctor doctor : FullDoctorList) {
                    if (doctor.getSpeciality().equals(type) && doctor.getGender().equals("Male"))
                        DoctorList.add(doctor);
                }
                break;
            case "Female":
                for (Doctor doctor : FullDoctorList) {
                    if (doctor.getSpeciality().equals(type) && doctor.getGender().equals("Female"))
                        DoctorList.add(doctor);
                }
                break;
        }
        ArrayAdapter<Doctor> arrayAdapter = new ArrayAdapter<Doctor>(getContext(), android.R.layout.simple_spinner_item, DoctorList);
        DoctorSpinner.setAdapter(arrayAdapter);
    }

    public void setGLC(Doctor doctor){
        location.setText(doctor.getLocation());
        credential.setText(doctor.getCredentials());
        gender.setText(doctor.getGender());
    }



}