package com.example.ses;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ses.record.Appointment;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class AppointmentAdaptor extends RecyclerView.Adapter<AppointmentAdaptor.AppointmentViewHolder>{
    private ArrayList<Appointment> mAppointmentList;
    private DatabaseReference database;

    public static class AppointmentViewHolder extends RecyclerView.ViewHolder {
        public TextView DoctorName, PatientName, DateTime, Details;
        public Button AcceptButton, DeclineButton;

        public AppointmentViewHolder(@NonNull View v) {
            super(v);
            DoctorName = v.findViewById(R.id.DoctorName);
            PatientName = v.findViewById(R.id.PatientName);
            DateTime = v.findViewById(R.id.DateTime);
            Details = v.findViewById(R.id.Details);
            AcceptButton = v.findViewById(R.id.AcceptButton);
            DeclineButton = v.findViewById(R.id.DeclineButton);

        }
    }
    public AppointmentAdaptor(ArrayList<Appointment> appointmentList) {
        mAppointmentList = appointmentList;
    }

    @NonNull
    @Override
    public AppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.doctor_request_item, parent, false);
        AppointmentViewHolder avh = new AppointmentViewHolder(v);
        return avh;
    }

    @Override
    public void onBindViewHolder(@NonNull AppointmentViewHolder holder, final int position) {
        final Appointment currentItem = mAppointmentList.get(position);
        holder.DoctorName.setText(currentItem.getDoctor().getName());
        holder.PatientName.setText(currentItem.getPatient().getName());
        holder.DateTime.setText(currentItem.getDate() + " " + currentItem.getTime());
        holder.Details.setText(currentItem.getDescription());
        database = FirebaseDatabase.getInstance().getReference();
        holder.AcceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentItem.setStatus("Accepted");
                database.child("Appointment").child(currentItem.getId()+"").setValue(currentItem);
            }
        });
        holder.DeclineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentItem.setStatus("Declined");
                database.child("Appointment").child(currentItem.getId()+"").setValue(currentItem);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mAppointmentList.size();
    }
}
