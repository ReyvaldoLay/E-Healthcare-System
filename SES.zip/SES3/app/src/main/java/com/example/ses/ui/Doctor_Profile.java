package com.example.ses.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.ses.MainActivity;
import com.example.ses.R;
import com.example.ses.record.Doctor;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Doctor_Profile extends Fragment implements View.OnClickListener{
    private TextView Name, Email, Gender;
    private EditText Location, Speciality, Credentials, Phone;
    private Button update;
    private Doctor doctor;
    private DatabaseReference database;
    private FirebaseUser mCurrentUser;
    private String current_uid;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.doctor_profile, container, false);
        return root;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        current_uid = mCurrentUser.getUid();
        Name = view.findViewById(R.id.DPName);
        Email = view.findViewById(R.id.DPEmail);
        Gender = view.findViewById(R.id.DPGender);
        Location = view.findViewById(R.id.DPLocation);
        Speciality = view.findViewById(R.id.DPSpeciality);
        Credentials = view.findViewById(R.id.DPCredentials);
        Phone = view.findViewById(R.id.DPPhone);
        update = view.findViewById(R.id.DPUpdate);
        update.setOnClickListener(this);


        database = FirebaseDatabase.getInstance().getReference();
        database.child("User").child("Doctor").child(current_uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                doctor= dataSnapshot.getValue(Doctor.class);
                setDoctorDetails(doctor);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setDoctorDetails(Doctor d){
                Name.setText(d.getName());
                Email.setText(d.geteMail());
                Gender.setText(d.getGender());
                Location.setText(d.getLocation());
                Speciality.setText(d.getSpeciality());
                Credentials.setText(d.getCredentials());
                Phone.setText(d.getPhone());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case(R.id.DPUpdate):
                doctor.setName(Name.getText().toString());
                doctor.setLocation(Location.getText().toString());
                doctor.setSpeciality(Speciality.getText().toString());
                doctor.setCredentials(Credentials.getText().toString());
                doctor.setPhone(Phone.getText().toString());
                database.child("User").child("Doctor").child(current_uid).setValue(doctor);
                Toast.makeText(getActivity(),"Details updated",Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
