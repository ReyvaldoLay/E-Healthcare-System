package com.example.ses.Users;

public class Doctor extends User {

    private String firstName, middleName, lastName, eMail, gender, location, speciality, credentials;
    private int id;

    public Doctor(String firstName, String middleName, String lastName, String eMail, String gender, int id, String location, String speciality, String credentials) {
        super(firstName, middleName, lastName, eMail, gender, id);
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.eMail = eMail;
        this.gender = gender;
        this.location = location;
        this.speciality = speciality;
        this.id = id;
        this.credentials = credentials;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getFullName() {
        return firstName + " " + middleName + " " + lastName;
    }

    public String getCredentials() {
        return credentials;
    }

    public void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    public String toString() {
        return getFullName();
    }
}
