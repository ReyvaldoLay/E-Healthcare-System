package com.example.ses.ui.RequestAppointment;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.ses.record.Appointment;
import com.example.ses.R;
import com.example.ses.record.Doctor;
import com.example.ses.record.Patient;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Request_Appointment extends Fragment implements View.OnClickListener{
    private TextView mDisplayDate, mDisplayTime, gender, location, credential;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private TimePickerDialog.OnTimeSetListener mTimeSetListener;
    private Button button1, button2, button3;
    private Spinner TypeSpinner, DoctorSpinner;
    private RadioGroup genderRadio;
    private RadioButton radioButton;
    private EditText editText2;
    private Doctor doctor;
    private Patient patient;
    private DatabaseReference database;
    private int id;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.request_appointment, container, false);
        return root;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final List<Doctor> DoctorList = new ArrayList<>();
        List<String> TypeList = new ArrayList<>();
        final List<Doctor> FullDoctorList = new ArrayList<>();
        mDisplayDate = view.findViewById(R.id.dateText);
        mDisplayTime = view.findViewById(R.id.TimeText);
        gender = view.findViewById(R.id.textView3);
        location = view.findViewById(R.id.textView5);
        credential = view.findViewById(R.id.textView6);
        editText2 = view.findViewById(R.id.editText2);
        genderRadio = view.findViewById(R.id.RadioGroupGender);
        button1 = view.findViewById(R.id.button1);
        button2 = view.findViewById(R.id.button2);
        button3 = view.findViewById(R.id.button3);
        DoctorSpinner = view.findViewById(R.id.DoctorSpinner);
        TypeSpinner = view.findViewById(R.id.TypeSpinner);
        button2.setOnClickListener(this);
        button1.setOnClickListener(this);
        button3.setOnClickListener(this);
        generateDoctors(FullDoctorList);
        initiateDoctorList(FullDoctorList,DoctorList);
        addTypes(TypeList);
        database = FirebaseDatabase.getInstance().getReference();

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                String date = day + "/" + month + "/" + year;
                mDisplayDate.setText(date);
            }
        };
        mTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hour, int minute) {
                String time = hour+":"+minute;
                mDisplayTime.setText(time);
            }
        };
        TypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id)
            {
                setDoctorSpinner(FullDoctorList, DoctorList);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        DoctorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                doctor = (Doctor)parent.getSelectedItem();
                setGLC(doctor);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        genderRadio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                setDoctorSpinner(FullDoctorList, DoctorList);
            }
        });
        database.child("Appointment").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                 id = (int) dataSnapshot.getChildrenCount();
                }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button2:
                Calendar calDate = Calendar.getInstance();
                int year = calDate.get(Calendar.YEAR);
                int month = calDate.get(Calendar.MONTH);
                int day = calDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialogDate = new DatePickerDialog(
                        getContext(),
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialogDate.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialogDate.show();
                break;

            case R.id.button3:
                Calendar calTime = Calendar.getInstance();
                int hour = calTime.get(Calendar.HOUR_OF_DAY);
                int minute = calTime.get(Calendar.MINUTE);

                TimePickerDialog dialogTime = new TimePickerDialog(
                        getContext(),
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mTimeSetListener,
                        hour, minute, true);
                dialogTime.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialogTime.show();
                break;

            case R.id.button1:
                        String text = mDisplayDate.getText()+" "+mDisplayTime.getText()+" "+DoctorSpinner.getSelectedItem().toString() +" "+ editText2.getText().toString();
                        Toast.makeText(getActivity(),text ,Toast.LENGTH_SHORT).show();
                        patient = new Patient("q","w","e","r","t",1,"y");
                        Appointment appointment = new Appointment(doctor,patient, mDisplayDate.getText().toString(),mDisplayTime.getText().toString(),editText2.getText().toString(),id+1,"Pending");

                        database.child("Appointment").child(id+1+"").setValue(appointment);
                        break;
        }
    }

    private void addTypes(List TypeList) {
        TypeList.add("TYPE 1");
        TypeList.add("TYPE 2");
        TypeList.add("TYPE 3");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, TypeList);
        TypeSpinner.setAdapter(arrayAdapter);
    }
    private void generateDoctors(List FullDoctorList){
        FullDoctorList.add(new Doctor("01", "Male", "TYPE1", "email", "Male", 01, "Just behind you", "TYPE 1", "Harvard graduate"));
        FullDoctorList.add(new Doctor("02", "Female", "TYPE1", "email", "Female", 02, "Over there", "TYPE 1", "Graduated there"));
        FullDoctorList.add(new Doctor("03", "Male", "TYPE2", "email", "Male", 03, "Just right here", "TYPE 2", "Ummm"));
        FullDoctorList.add(new Doctor("04", "Female", "TYPE2", "email", "Female", 04, "That place right there", "TYPE 2", "Running out of ideas"));
        FullDoctorList.add(new Doctor("05", "Male", "TYPE3", "email", "Male", 05, "I dont actually know", "TYPE 3", "Is anyone reading this?"));
        FullDoctorList.add(new Doctor("06", "Female", "TYPE3", "email", "Female", 06, "Randwik?", "TYPE 3", "oh no"));

    }

    private void initiateDoctorList(List<Doctor> FullDoctorList, List DoctorList){
        for(Doctor doctor : FullDoctorList)
        {
            if(doctor.getSpeciality().equals("TYPE 1"))
                DoctorList.add(doctor.getFirstName() +" "+ doctor.getMiddleName() + " " +doctor.getLastName());
        }
        ArrayAdapter<Doctor> arrayAdapter = new ArrayAdapter<Doctor>(getContext(), android.R.layout.simple_spinner_item, DoctorList);
        DoctorSpinner.setAdapter(arrayAdapter);
    }

    private void setDoctorSpinner(List<Doctor> FullDoctorList, List<Doctor> DoctorList) {
        int selectedId = genderRadio.getCheckedRadioButtonId();
        radioButton = getView().findViewById(selectedId);
        String type = TypeSpinner.getSelectedItem().toString();
        DoctorList.clear();
        switch (radioButton.getText().toString()) {
            case "Both":
                for (Doctor doctor : FullDoctorList) {
                    if (doctor.getSpeciality().equals(type))
                        DoctorList.add(doctor);
                }
                break;
            case "Male":
                for (Doctor doctor : FullDoctorList) {
                    if (doctor.getSpeciality().equals(type) && doctor.getGender().equals("Male"))
                        DoctorList.add(doctor);
                }
                break;
            case "Female":
                for (Doctor doctor : FullDoctorList) {
                    if (doctor.getSpeciality().equals(type) && doctor.getGender().equals("Female"))
                        DoctorList.add(doctor);
                }
                break;
        }
        ArrayAdapter<Doctor> arrayAdapter = new ArrayAdapter<Doctor>(getContext(), android.R.layout.simple_spinner_item, DoctorList);
        DoctorSpinner.setAdapter(arrayAdapter);
    }

    public void setGLC(Doctor doctor){
        location.setText(doctor.getLocation());
        credential.setText(doctor.getCredentials());
        gender.setText(doctor.getGender());
    }

}
