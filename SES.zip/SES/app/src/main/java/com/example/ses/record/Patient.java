package com.example.ses.record;

public class Patient{

    private String firstName, middleName, lastName, eMail, gender, location,fullName;
    private int id;
    public Patient(){}
    public Patient(String firstName, String middleName, String lastName, String eMail, String gender, int id, String location) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.eMail = eMail;
        this.gender = gender;
        this.location = location;
        this.id = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getFullName() {
        return firstName + " " + middleName + " " + lastName;
    }
    public void SetFullName(String f, String m, String l) {
        this.fullName = f +" "+ m +" "+ l;
    }

    public String toString() {
        return getFullName();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

