package com.example.ses.ui;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.ses.Doctor_Request;
import com.example.ses.R;
import com.example.ses.record.Appointment;
import com.example.ses.record.Doctor;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Doctor_Busy extends Fragment implements View.OnClickListener{

    private Button date, UpdateButton;
    private TextView dateDisplay;
    private List<String> Busy;
    private List<CheckBox> Boxes;
    private CheckBox box9a,box9b, box10a, box10b, box11a, box11b, box12a, box12b, box13a, box13b, box14a, box14b, box15a, box15b, box16a, box16b;
    private DatabaseReference database;
    private DatePickerDialog.OnDateSetListener dateDisplayListener;
    private Doctor doctor;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.doctor_busy, container, false);
        return root;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        doctor = new Doctor("01", "Male", "TYPE1", "email", "Male", 01, "Just behind you", "TYPE 1", "Harvard graduate");
        Busy = new ArrayList<>();
        Boxes = new ArrayList<>();
        date = view.findViewById(R.id.dateButton);
        UpdateButton = view.findViewById(R.id.UpdateButton);
        dateDisplay = view.findViewById(R.id.dateText);
        box9a = view.findViewById(R.id.box9);
        box9b = view.findViewById(R.id.box9_5);
        box10a = view.findViewById(R.id.box10);
        box10b = view.findViewById(R.id.box10_5);
        box11a = view.findViewById(R.id.box11);
        box11b = view.findViewById(R.id.box11_5);
        box12a = view.findViewById(R.id.box12);
        box12b = view.findViewById(R.id.box12_5);
        box13a = view.findViewById(R.id.box13);
        box13b = view.findViewById(R.id.box13_5);
        box14a = view.findViewById(R.id.box14);
        box14b = view.findViewById(R.id.box14_5);
        box15a = view.findViewById(R.id.box15);
        box15b = view.findViewById(R.id.box15_5);
        box16a = view.findViewById(R.id.box16);
        box16b = view.findViewById(R.id.box16_5);
        date.setOnClickListener(this);
        UpdateButton.setOnClickListener(this);
        setBoxes();
        database = FirebaseDatabase.getInstance().getReference();

        dateDisplayListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                String date = day + "-" + month + "-" + year;
                dateDisplay.setText(date);
                setCheck();
            }
        };
        database.child("Busy_Times").child(doctor.getId()+"").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Busy.clear();
                for(DataSnapshot child : dataSnapshot.getChildren()){
                    String i  = child.getKey();
                    Busy.add(i);
                }
                Toast.makeText(getActivity(),"busy times are loaded",Toast.LENGTH_SHORT).show();
                view.findViewById(R.id.loadingPanel).setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.dateButton:
                Calendar calDate = Calendar.getInstance();
                int year = calDate.get(Calendar.YEAR);
                int month = calDate.get(Calendar.MONTH);
                int day = calDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialogDate = new DatePickerDialog(
                        getContext(),
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        dateDisplayListener,
                        year, month, day);
                dialogDate.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialogDate.show();
                break;
            case R.id.UpdateButton:
                Toast.makeText(getActivity(),Busy.size()+"",Toast.LENGTH_SHORT).show();
                String date = dateDisplay.getText().toString();
                if(!date.equals("DD-MM-YYYY")) {
                    for (CheckBox j : Boxes)
                        if (j.isChecked()) {
                            database.child("Busy_Times/" + doctor.getId() + "/" + date + " " + j.getText()).setValue("");
                        } else {
                            database.child("Busy_Times/" + doctor.getId() + "/" + date + " " + j.getText()).setValue(null);
                        }
                }
                else {
                    Toast.makeText(getActivity(),"please choose a date", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    public void setBoxes(){
        Boxes.clear();
        Boxes.add(box9a);
        Boxes.add(box9b);
        Boxes.add(box10a);
        Boxes.add(box10b);
        Boxes.add(box11a);
        Boxes.add(box11b);
        Boxes.add(box12a);
        Boxes.add(box12b);
        Boxes.add(box13a);
        Boxes.add(box13b);
        Boxes.add(box14a);
        Boxes.add(box14b);
        Boxes.add(box15a);
        Boxes.add(box15b);
        Boxes.add(box16a);
        Boxes.add(box16b);
    }

    public void setCheck(){
        for(CheckBox k: Boxes)
            k.setChecked(false);
        for(String i : Busy){
            String [] split = i.split(" ");
            if(split[0].equals(dateDisplay.getText().toString())){
                for(CheckBox j : Boxes){
                    if(j.getText().toString().equals(split[1])) {
                        j.setChecked(true);
                    }
                }
            }
        }
    }
}
