package com.example.ses;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.ses.record.Doctor;
import com.example.ses.record.Patient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.regex.Pattern;

public class Register extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +        //any letter
                    //"(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +             //no white spaces
                    ".{6,}" +                 //at least 4 characters
                    "$");

    private EditText mTextEmail;
    private EditText mTextPassword;
    private EditText mTextPhone;
    private EditText mTextAddress;
    private Button registerBtn;
    private Button loginBtn;
    private DatabaseReference database;
    private RadioGroup userRadioGroup, genderRadioGroup;
    private RadioButton userRadioBtn, genderRadioBtn;
    private int Pid=0, Did=0;
    private FirebaseAuth mAuth;
    private ProgressDialog mRegProgress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mTextEmail = (EditText) findViewById(R.id.inputNewEmail);
        mTextPassword = (EditText) findViewById(R.id.inputCfnPW);
        mTextPhone = (EditText) findViewById(R.id.inputPhone);
        mTextAddress = (EditText) findViewById(R.id.inputAddress);
        registerBtn = (Button) findViewById(R.id.registerBtn);
        loginBtn = (Button) findViewById(R.id.loginBtn2);
        mRegProgress = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        database = FirebaseDatabase.getInstance().getReference();

        userRadioGroup = findViewById(R.id.radioGroup);
        genderRadioGroup = findViewById(R.id.radioGender);

       registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mTextEmail.getText().toString().trim();
                String password = mTextPassword.getText().toString().trim();
                String phone = mTextPhone.getText().toString().trim();
                String address = mTextAddress.getText().toString().trim();

                int radioId = userRadioGroup.getCheckedRadioButtonId();
                userRadioBtn = findViewById(radioId);
                String userType = userRadioBtn.getText().toString().trim();

                genderRadioBtn = findViewById(genderRadioGroup.getCheckedRadioButtonId());
                String gender = genderRadioBtn.getText().toString().trim();



                if(validateEmail() == true && validatePassword() == true && validatePhone() == true && validateAddress() == true) {
                    mRegProgress.setTitle("Registering User");
                    mRegProgress.setMessage("Please wait while we create your account");
                    mRegProgress.setCanceledOnTouchOutside(false);
                    mRegProgress.show();
                    register_user("",email,password,phone,address, userType, gender);
                }
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginPage = new Intent(Register.this, Login.class);
                startActivity(loginPage);
            }
        });
        database.child("User").child("Patient").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot x : dataSnapshot.getChildren()){
                    Patient patient  = x.getValue(Patient.class);
                    if(patient.getId()>Pid){Pid = patient.getId();}
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        database.child("User").child("Doctor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot x : dataSnapshot.getChildren()){
                    Doctor doctor  = x.getValue(Doctor.class);
                    if(doctor.getId()>Did){Did = doctor.getId();}
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void checkButton(View v) {
        int radioId = userRadioGroup.getCheckedRadioButtonId();
        userRadioBtn = findViewById(radioId);
        //Toast.makeText(this, "Seclected user type: " + userRadioBtn.getText(), Toast.LENGTH_SHORT).show();
    }

    private boolean validateEmail() {
        String emailInput = mTextEmail.getText().toString().trim();

        if (emailInput.isEmpty()) {
            mTextEmail.setError("Email can't be empty");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            mTextEmail.setError("Please enter a valid email address");
            return false;
        } else {
            mTextEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = mTextPassword.getText().toString().trim();

        if (passwordInput.isEmpty()) {
            mTextPassword.setError("Password can't be empty");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            mTextPassword.setError("Password too weak");
            return false;
        } else {
            mTextPassword.setError(null);
            return true;
        }
    }

    private boolean validatePhone() {
        String phoneInput = mTextPhone.getText().toString().trim();

        if (phoneInput.isEmpty()) {
            mTextPhone.setError("No phone number entered");
            return false;
        } else {
            mTextPhone.setError(null);
            return true;
        }
    }

    private boolean validateAddress() {
        String addressInput = mTextAddress.getText().toString().trim();

        if (addressInput.isEmpty()) {
            mTextPhone.setError("No residential address entered");
            return false;
        } else {
            mTextPhone.setError(null);
            return true;
        }
    }

    private void register_user(final String name, final String email, final String password, final String phone, final String address, final String userType, final String gender) {

        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){

                    FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
                    String uid = current_user.getUid();

                    database = FirebaseDatabase.getInstance().getReference().child("User").child(userType).child(uid);

                    Patient patient = new Patient("", email, password, phone, address, Pid+1, gender);
                    Doctor doctor = new Doctor("", email, gender, Did+1, address,"", "", phone, password);
                    Object user = null;
                    if(userType.equals("Doctor")){user = doctor;}
                    if(userType.equals("Patient")){user = patient;}

                    database.setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if(task.isSuccessful()) {
                            }
                            mRegProgress.dismiss();

                            Intent mainIntent = new Intent(Register.this, MainActivity.class);
                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(mainIntent);
                            finish();
                        }
                    });

                } else {

                    mRegProgress.hide();
                    Toast.makeText(Register.this, "Email is already used", Toast.LENGTH_LONG).show();

                }

            }
        });
    }
}
